﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationSampleCode.UnitTests
{
    [TestClass]
    public class PhoneNumberTests
    {
        [TestMethod]
        public void Parse_ValidNumber_ReturnsPhoneNumberObject()
        {
            string validNumber = "0123456789";

            PhoneNumber phoneNumber = PhoneNumber.Parse(validNumber);

            Assert.IsNotNull(phoneNumber);
            Assert.AreEqual("012", phoneNumber.Area);
            Assert.AreEqual("345", phoneNumber.Major);
            Assert.AreEqual("6789", phoneNumber.Minor);
        }

        [TestMethod]
        public void Parse_NullOrBlankNumber_ThrowsArgumentException()
        {
            string nullOrBlankNumber = null;

            Assert.ThrowsException<ArgumentException>(() => PhoneNumber.Parse(nullOrBlankNumber));

            nullOrBlankNumber = " ";

            Assert.ThrowsException<ArgumentException>(() => PhoneNumber.Parse(nullOrBlankNumber));
        }

        [TestMethod]
        public void Parse_InvalidLengthNumber_ThrowsArgumentException()
        {
            string invalidLengthNumber = "123456789";

            Assert.ThrowsException<ArgumentException>(() => PhoneNumber.Parse(invalidLengthNumber));
        }

        [TestMethod]
        public void ToString_ValidPhoneNumber_ReturnsFormattedString()
        {
            PhoneNumber phoneNumber = PhoneNumber.Parse("0123456789");

            string result = phoneNumber.ToString();

            Assert.AreEqual("(012)345-6789", result);
        }
    }
}
