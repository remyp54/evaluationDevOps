namespace EvaluationSampleCode.UnitTests
{
    [TestClass]
        public class MathOperationsTests
        {
            private MathOperations mathOperations;

            [TestInitialize]
            public void Setup()
            {
                mathOperations = new MathOperations();
            }

            [TestMethod]
            [DataRow(5, 3, 2)]
            [DataRow(10, 5, 5)]
            [DataRow(0, 0, 0)]
            public void Subtract_ValidInput_ReturnsCorrectResult(int numberOne, int numberTwo, int expectedResult)
            {
                int result = mathOperations.Subtract(numberOne, numberTwo);

                Assert.AreEqual(expectedResult, result);
            }

            [TestMethod]
            [DataRow(1200, 5)]
            [DataRow(1500, 100)]
            public void Subtract_InvalidInput_ThrowsArgumentException(int numberOne, int numberTwo)
            {
                Assert.ThrowsException<ArgumentException>(() => mathOperations.Subtract(numberOne, numberTwo));
            }

            [TestMethod]
            [DataRow(5, "Red")]
            [DataRow(8, "Blue")]
            [DataRow(0, "Red")]
            public void GetColorFromOddsNumber_ValidInput_ReturnsCorrectColor(int number, string expectedColor)
            {
                string result = mathOperations.GetColorFromOddsNumber(number);

                Assert.AreEqual(expectedColor, result);
            }
    
            [TestMethod]
            [DataRow(-5)]
            [DataRow(-10)]
            public void GetColorFromOddsNumber_InvalidInput_ThrowsArgumentException(int number)
            {
                Assert.ThrowsException<ArgumentException>(() => mathOperations.GetColorFromOddsNumber(number));
            }
        }
}