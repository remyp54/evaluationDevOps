﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationSampleCode.UnitTests
{
    [TestClass]
    public class HtmlFormatHelperTests
    {
        private HtmlFormatHelper htmlFormatHelper;

        [TestInitialize]
        public void Setup()
        {
            htmlFormatHelper = new HtmlFormatHelper();
        }

        [TestMethod]
        public void GetStrongFormat_ShouldReturnCorrectFormat()
        {
            string content = "Hello";

            string result = htmlFormatHelper.GetStrongFormat(content);

            Assert.AreEqual("<strong>Hello</strong>", result);
        }

        [TestMethod]
        public void GetItalicFormat_ShouldReturnCorrectFormat()
        {
            string content = "World";

            string result = htmlFormatHelper.GetItalicFormat(content);

            Assert.AreEqual("<i>World</i>", result);
        }

        [TestMethod]
        public void GetFormattedListElements_ShouldReturnCorrectFormat()
        {
            List<string> contents = new List<string> { "Item1", "Item2", "Item3" };

            string result = htmlFormatHelper.GetFormattedListElements(contents);

            Assert.AreEqual("<ul><li>Item1</li><li>Item2</li><li>Item3</li></ul>", result);
        }
    }
}
