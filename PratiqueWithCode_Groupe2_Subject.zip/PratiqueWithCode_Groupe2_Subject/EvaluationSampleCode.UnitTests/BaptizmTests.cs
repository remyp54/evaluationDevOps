﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationSampleCode.UnitTests
{
    [TestClass]
    public class BaptizmTests
    {
        [TestMethod]
        public void CanBeBaptizedBy_Priest_ReturnsTrue()
        {
            ClergyMember priest = new ClergyMember { IsPriest = true };
            Baptizm baptizm = new Baptizm(new ClergyMember());

            bool result = baptizm.CanBeBaptizedBy(priest);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanBeBaptizedBy_Pope_ReturnsTrue()
        {
            ClergyMember pope = new ClergyMember { IsPope = true };
            Baptizm baptizm = new Baptizm(new ClergyMember());

            bool result = baptizm.CanBeBaptizedBy(pope);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanBeBaptizedBy_OtherClergyMember_ReturnsFalse()
        {
            ClergyMember clergyMember = new ClergyMember();
            Baptizm baptizm = new Baptizm(new ClergyMember());

            bool result = baptizm.CanBeBaptizedBy(clergyMember);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CanBeTeachedBy_SameClergyMember_ReturnsTrue()
        {
            ClergyMember clergyMember = new ClergyMember();
            Baptizm baptizm = new Baptizm(clergyMember);

            bool result = baptizm.CanBeTeachedBy(clergyMember);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanBeTeachedBy_OtherClergyMember_ReturnsFalse()
        {
            ClergyMember clergyMember = new ClergyMember();
            Baptizm baptizm = new Baptizm(new ClergyMember());

            bool result = baptizm.CanBeTeachedBy(clergyMember);

            Assert.IsFalse(result);
        }
    }
}
